# Google Review Placa — V8 Mobile

Versão moderna para Android e iPhone, sem API Key, Google Cloud, Node.js ou servidor local.

## Fluxo
1. Digite a empresa e a cidade.
2. Toque em "Abrir no Maps".
3. No Google Maps, escolha a ficha correta.
4. Toque em Compartilhar → Copiar link.
5. Volte para a V8 e toque em "Colar link" ou cole manualmente.
6. Toque em "Gerar avaliação".
7. Use Copiar, Abrir, Compartilhar ou QR Code.

## Android / iPhone
A página pode ser instalada como PWA quando estiver publicada em HTTPS.
- Android/Chrome: abra o site e use "Adicionar à tela inicial" quando aparecer.
- iPhone/Safari: Compartilhar → Adicionar à Tela de Início.

## Observações
- Não usa API Key.
- Não envia o link para um servidor próprio.
- Reconhece Place ID (ChIJ...) e identificadores internos 0x...:0x... presentes em muitos links do Google Maps.
- O QR Code usa qrcodejs via CDN; se o CDN estiver indisponível, o restante da ferramenta continua funcionando.
- Para instalação PWA, publique os arquivos em HTTPS. Abrir o HTML diretamente como arquivo pode não ativar o Service Worker.

## Compatibilidade
Chrome/Android, Safari/iPhone, Chrome/iPhone e navegadores modernos com suporte a clipboard/share.
